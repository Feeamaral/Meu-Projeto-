function filtrar() {
    var selectMes = Number(select_mes.value);
    var selectPais = Number(select_pais.value);
    var selectPreco = Number(select_Preco.value);
    var selectAcompanhante = Number(select_acompanhante.value);


    //Filtrando por preco-janeiro-nacional-filho
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 1) {

                    img19.style.display = 'block';
                    img25.style.display = 'none';
                    img20.style.display = 'none';
                    img6.style.display = 'none';
                    img23.style.display = 'none';

                }
            }
        }
    }
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img6.style.display = 'block';


                }
            }
        }
    }

    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img23.style.display = 'block';
                    img25.style.display = 'none';
                    img20.style.display = 'none';
                    img6.style.display = 'none';

                }
            }
        }
    }

    //filtrando por preço - janeiro -nacional - conjuge
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 2) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img6.style.display = 'block';
                    img23.style.display = 'none';

                }
            }
        }
    }
    /* if (selectMes == 1) {
         if (selectPais == 1) {
             if (selectPreco == 5) {
                 if (selectAcompanhante == 2) {

                     img25.style.display = 'none';
                     img20.style.display = 'none';
                     img6.style.display = 'none';
                     img23.style.display = 'none';
                     img18.style.display = 'block';

                 }
             }
         }
     }*/
    //filtrando por preço - janeiro -nacional - amigos
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';

                }
            }
        }
    }
    if (selectMes == 1) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';
                    img25.style.display = 'block';
                    img20.style.display = 'block';

                }
            }
        }
    }
    //filtrando fevereiro

    if (selectMes == 2 && selectPais == 1 && selectPreco == 1 && selectAcompanhante == 1) {

        img18.style.display = 'block';

    }
    if (selectMes == 2 && selectPais == 1 && selectPreco == 2 && selectAcompanhante == 1) {

        img25.style.display = 'block';
        img20.style.display = 'block';
        img18.style.display = 'block';
        img6.style.display = 'block';

    }
    if (selectMes == 2 && selectPais == 1 && selectPreco == 3 && selectAcompanhante == 1) {

        img25.style.display = 'none';
        img20.style.display = 'block';
        img18.style.display = 'none';
        img6.style.display = 'block';

    }

    if (selectMes == 2) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'none';
                    img20.style.display = 'none';
                    img18.style.display = 'none';
                    img6.style.display = 'none';
                    img23.style.display = 'block';
                    img2.style.display = 'none';
                    img3.style.display = 'none';
                    img4.style.display = 'none';

                }
            }
        }
    }

    //filtrando por preço - fevereiro -nacional - conjuge
    if (selectMes == 2) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img6.style.display = 'block';
                }
            }
        }
    }
    //filtrando por preço - feveriro -nacional - amigos
    if (selectMes == 2) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';

                }
            }
        }
    }
    if (selectMes == 2) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';
                    img25.style.display = 'block';
                    img20.style.display = 'block';

                }
            }
        }
    }

    //Filtrando por preco-março-nacional-filho
    if (selectMes == 3) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 1) {

                    console.log("x")
                    img19.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 3) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 3) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 3) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 3) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img23.style.display = 'block';

                }
            }
        }
    }

    //filtrando por preço - abril -nacional - conjuge
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 2) {

                    img22.style.display = 'block';
                    img21.style.display = 'block';
                    img6.style.display = 'block';
                }
            }
        }
    }
    //filtrando por preço - abril -nacional - amigos
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 3) {


                    img21.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';
                    img25.style.display = 'block';
                    img20.style.display = 'block';

                }
            }
        }
    }

    //Filtrando por preco-abril-nacional-filho
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 1) {

                    img19.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img23.style.display = 'block';

                }
            }
        }
    }


    //filtrando por preço - abril -nacional - amigos
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';
                    img24.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';
                    img25.style.display = 'block';
                    img20.style.display = 'block';

                }
            }
        }
    }
    //filtrando por preço - abril -nacional - conjuge
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 2) {

                    img23.style.display = 'block';
                    img24.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 4) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 2) {

                    img6.style.display = 'block';
                    img25.style.display = 'block';
                    img20.style.display = 'block';

                }
            }
        }
    }

    //Filtrando por preco-janeiro-nacional-filho
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 1) {

                    img19.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 1) {

                    img17.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';


                }
            }
        }
    }
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 1) {

                    img25.style.display = 'block';
                    img20.style.display = 'block';
                    img18.style.display = 'block';
                    img4.style.display = 'none';
                    img8.style.display = 'none';


                }
            }
        }
    }
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img23.style.display = 'block';

                }
            }
        }
    }

    //filtrando por preço - janeiro -nacional - conjuge
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 3) {
                if (selectAcompanhante == 2) {

                    img16.style.display = 'block';
                    img17.style.display = 'block';
                    img25.style.display = 'none';
                    img20.style.display = 'none';
                    img18.style.display = 'none';

                }
            }
        }
    }
    //filtrando por preço - janeiro -nacional - amigos
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 1) {
                if (selectAcompanhante == 3) {

                    img19.style.display = 'block';

                }
            }
        }
    }
    if (selectMes == 5) {
        if (selectPais == 1) {
            if (selectPreco == 2) {
                if (selectAcompanhante == 3) {

                    img6.style.display = 'block';
                    img16.style.display = 'block';
                    img17.style.display = 'block';

                }
            }
        }
    }

    //filtrando destinos internacionais

    if (selectMes == 1 ) {
        if (selectPais == 2) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 1) {

                    img2.style.display = 'none';
                    img3.style.display = 'block';
                    img4.style.display = 'block';
                    img16.style.display = 'none';
                    img17.style.display = 'none';
                    img23.style.display = 'none';


                }
            }
        }
    }
    if (selectMes == 1 ) {
        if (selectPais == 2) {
            if (selectPreco == 4) {
                if (selectAcompanhante == 2) {

                    img2.style.display = 'block';
                    img3.style.display = 'block';
                    img4.style.display = 'block';
                    img16.style.display = 'none';
                    img17.style.display = 'none';
                    img23.style.display = 'none';


                }
            }
        }
    }
}

